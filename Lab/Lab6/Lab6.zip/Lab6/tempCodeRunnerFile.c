
        _min_ = arr[i+1];